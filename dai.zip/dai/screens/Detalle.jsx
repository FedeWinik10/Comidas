import React, { useContext, useEffect, useState} from 'react';
import { StyleSheet, Text, View, Image, Button } from 'react-native';
import { getPlatoByID } from '../services/axios';
import { ContextComida } from '../Context'


const DetallePlato = ({ route, navigation }) => {
  const { id } = route.params;           //Trae el id del plato elegido
  const context = useContext(ContextComida) //Trae el contexto

  const [plato, setPlato] = useState({});

  useEffect(() => {
    if(!context.authToken){
      navigation.navigate("logIn") //Si no hay token en el contexto, te manda a la pantalla de login
    }
    console.log("HAY TOKEN")

    getPlatoByID(id).then(r => setPlato(r));
  }, [])

  let platoExiste = context.menu.find(item => item.id === id)   //Busca si el plato ya esta en el menu

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{plato.title}</Text>
      <Image style={styles.image} source={ plato.image }></Image>         
      <Text>Health Score: {plato.healthScore}</Text>
      <Text>${plato.pricePerServing}</Text>
      {
        plato.vegan ? 
            <Text>Vegano: Sí</Text>
        :
            <Text>Vegano: No</Text>
      }
      { plato.vegetarian ?
          <Text>Vegetariano: Sí</Text>
      :
          <Text>Vegetariano: No</Text>
      }
      {
        (typeof platoExiste !== "undefined")
          ?
          <>
            <Button style={{ fontSize: 48 }}
              title="ELIMINAR"
              onPress={async () => {
                console.log("Eliminando del menu")
                let newMenu = context.menu.filter(element => element.id !== plato.id);
                context.setMenu(newMenu);
                navigation.navigate('Home')
              }}
            />
          </>
          :
          <>
            <Button
              title="AGREGAR"
              onPress={async () => {
                let countVegan = 0;
                let countNoVegan = 0;

                for (let i = 0; i < context.menu.length; i++) {
                  if(context.menu[i].vegan){
                    countVegan++;
                  }else{
                    countNoVegan++;
                  }
                }
                console.log("countVegan", countVegan);
                console.log("countNonVegan", countNoVegan);

                if(countVegan==2 && countNoVegan==2){
                  console.log("No se pueden agregar más platos")
                }
                else{
                  if(plato.vegan){
                    if(countVegan==2){
                      console.log("No se pueden agregar más platos veganos")
                    }
                    else{
                      console.log("Agregando al menu")
                      context.setMenu([...context.menu, plato])
                      navigation.navigate('Home')
                    }
                  }
                  else{
                    if(countNoVegan==2){
                      console.log("No se pueden agregar más platos no veganos")
                    }else{
                      console.log("Agregando al menu")
                      context.setMenu([...context.menu, plato]);
                      navigation.navigate('Home')
                    }
                  }
                }
              }}
            />
          </>
      }
    </View>

  );
}
export default DetallePlato

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent:'center',
    alignItems: 'center',
    backgroundColor:'white',
  },
  item: {
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 12,
  },
  image: {
    width: 300,
    height: 300,
  },
  title:{
    fontSize: 45,
    marginRight: 'auto',
    marginLeft: 'auto',
  }
});