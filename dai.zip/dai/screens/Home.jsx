import React, { useContext, useEffect, useState } from 'react';
import { StyleSheet, Text, View, TextInput, TouchableOpacity, FlatList, Image } from 'react-native';
import { GetPlatos } from '../services/axios';
import { ContextComida } from '../Context';

const Item = ({ title, image, navigation, id }) => (
  <TouchableOpacity
    onPress={() => { navigation.navigate('Detalle', { id }) }}
  >
    <View style={styles.item}>
      <Image style={styles.image} source={image}></Image>
      <Text style={styles.title}>{title}</Text>
    </View>
  </TouchableOpacity>
);

const Home = ({ navigation }) => {
  const context = useContext(ContextComida);
  const [healthscore, setHealthscore] = useState(0);
  const [precio, setPrecio] = useState(0);

  useEffect(() => {
    if (!context.authToken) {
      console.log('No hay token');
      navigation.navigate("logIn");
    } else {
      console.log("HAY TOKEN");
    }
  }, [context.authToken, navigation]);

  useEffect(() => {
    let sumaHealth = 0;
    let totalPrice = 0;

    context.platos.forEach((plato) => {
      sumaHealth += plato.healthScore;
      totalPrice += plato.pricePerServing;
    });

    if (context.platos.length > 0) {
      const newHealthscore = sumaHealth / context.platos.length;
      setHealthscore(newHealthscore.toFixed(2));
      setPrecio(totalPrice.toFixed(2));
    } else {
      setHealthscore(0);
      setPrecio(0);
    }
  }, [context.platos]);

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Buscador</Text>
      <TextInput
        style={styles.input}
        placeholder="Buscar"
        onChangeText={text => {
          if (text.length > 2) {
            GetPlatos(text).then((data) => {
              context.setPlatos(data);
            }).catch(() => {
              console.log("error");
            });
          }
        }}
      />

      <Text style={styles.titulo}>Resultados de la Búsqueda</Text>
      {context.platos.length > 0 ? (
        <FlatList
          data={context.platos}
          renderItem={({ item }) => <Item navigation={navigation} title={item.title} image={item.image} id={item.id} />}
          keyExtractor={item => item.id}
        />
      ) : (
        <Text>No se encontraron resultados.</Text>
      )}

      <Text style={styles.titulo}>MENU</Text>
      <Text style={styles.precio}>PRECIO: ${precio}</Text>
      <Text style={styles.healthscore}>PROMEDIO HEALTHSCORE: {healthscore} </Text>

      <Text style={styles.titulo}>Menú de Restaurant</Text>
      {context.menu.length > 0 ? (
        <FlatList
          data={context.menu}
          renderItem={({ item }) => <Item navigation={navigation} title={item.title} image={item.image} id={item.id} />}
          keyExtractor={item => item.id}
        />
      ) : (
        <Text>No hay elementos en el menú.</Text>
      )}
    </View>
  );
}

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 16,
  },
  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    backgroundColor: 'white',
    borderRadius: 5,
    paddingHorizontal: 16,
    marginBottom: 16,
    height: 40,
    borderWidth: 1,
    width: '100%',
  },
  item: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 16,
    marginVertical: 8,
    flexDirection: 'row',
    alignItems: 'center',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  image: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  precio: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  healthscore: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 16,
  },
});