import { createContext } from "react";

const ContextComida = createContext();

export {ContextComida};