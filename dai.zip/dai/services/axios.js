import axios from 'axios';

export const GetPlatos = async (Plato) => {
    console.log(Plato)
    return axios.get(`https://api.spoonacular.com/recipes/complexSearch?apiKey=f9a05f98f8874be5bb7f101683c8ee8d&query=${Plato}`,{})
    .then(async(res) => {
        console.log(res.data.results)
        return res.data.results   //devuelve un array de platos
    })
    .catch(() => {
      throw "error" 
    });
};
 
export const getPlatoByID = async (id) => {
    return axios.get(`https://api.spoonacular.com/recipes/${id}/information?apiKey=f9a05f98f8874be5bb7f101683c8ee8d`,{})  
    .then(function(res){
        return res.data  
    })
    .catch(() => {
        throw "Error" 
    });
};

export const enterLogin = async (user) => {
    console.log(user)
    return axios.post(`http://challenge-react.alkemy.org`, {
        ...user
      })
      .then(() => {
        return true   
      })
      .catch(() => {
        throw "error" 
      });
  };

