import React, { useState } from 'react';
import MainStack from './navigation/MainStack';
import { ContextComida } from './Context';

export default function App() {
  
  const [authToken, setAuthToken] = useState("");
  const [menu, setMenu] = useState([]);
  const [platos, setPlatos] = useState([]);

  return ( 
         <ContextComida.Provider value={{authToken, setAuthToken, menu, setMenu, platos, setPlatos}}>
          <MainStack/>
         </ContextComida.Provider>  
  );

} 